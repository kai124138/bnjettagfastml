#ifndef MYPROJECT_H_
#define MYPROJECT_H_

#include "ap_fixed.h"
#include "ap_int.h"
#include "hls_stream.h"

#include "defines.h"


// Prototype of top level function for C-synthesis
void myproject(
    inp_t inp[256],
    result_t layer4_out[256]
);

// hls-fpga-machine-learning insert emulator-defines


#endif
